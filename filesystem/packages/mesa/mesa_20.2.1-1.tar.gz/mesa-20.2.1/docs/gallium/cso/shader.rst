.. _shader:

Shader
======

One of the two types of shaders supported by Gallium.

Members
-------

tokens
    A list of tgsi_tokens.
